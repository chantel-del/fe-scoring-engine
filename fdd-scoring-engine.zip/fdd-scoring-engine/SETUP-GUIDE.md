# The Ultimate Franchise Scoring Engine — Setup Guide

Everything ships in two pieces. The **page** lives on your HubSpot site. The **engine** (which holds your Anthropic API key and does the scoring) lives on Vercel, a free hosting service. The page calls the engine, the engine scores the FDD, saves the lead into HubSpot, and returns the result to the page.

Total setup time: roughly 30–40 minutes, no coding required.

---

## What's in this folder

| File | What it is |
|---|---|
| `frontend/hubspot-page.html` | The complete landing page — paste into HubSpot |
| `backend/api/score.js` | The API endpoint the page calls |
| `backend/lib/scoring.js` | The hard-coded scoring framework (v2.3, Sections 2+3) |
| `backend/lib/extract.js` | The Claude step that reads Items 6/7/19/20 |
| `backend/lib/hubspot.js` | Writes the lead + score into HubSpot |
| `backend/test/scoring.test.js` | Automated tests (all passing) |
| `backend/.env.example` | The three secret keys the engine needs |

---

## Part 1 — Deploy the engine to Vercel (~15 min)

1. Go to **vercel.com** and sign up (free "Hobby" plan is fine). You can sign up with an email or a GitHub account.
2. The easiest upload path is Vercel's command line, but if you prefer zero terminal work: create a free **GitHub** account, create a new repository called `fe-scoring-engine`, and upload the entire contents of the `backend` folder to it (GitHub has an "uploading an existing file" drag-and-drop on every new repo). Then in Vercel click **Add New > Project**, import that repository, and click **Deploy**.
3. Once deployed, Vercel gives you a URL like `https://fe-scoring-engine.vercel.app`. **Write this down** — your API lives at `https://fe-scoring-engine.vercel.app/api/score`.
4. In Vercel, open your project → **Settings → Environment Variables** and add these three (values explained in Parts 2 and 3):
   - `ANTHROPIC_API_KEY` — your key from console.anthropic.com
   - `HUBSPOT_TOKEN` — created in Part 2 below
   - `ALLOWED_ORIGIN` — `https://www.franchiseempire.com`
5. After adding the variables, go to **Deployments** and click **Redeploy** so they take effect.

> Your Anthropic key: log into **console.anthropic.com → API Keys → Create Key**. Copy it immediately (it's shown once). Each FDD scored costs roughly $0.05–0.30 in API usage depending on document size.

---

## Part 2 — HubSpot: token + contact properties (~10 min)

### 2a. Create a Private App token
1. In HubSpot: **Settings (gear icon) → Integrations → Private Apps → Create a private app**.
2. Name it `FDD Scoring Engine`.
3. On the **Scopes** tab, enable: `crm.objects.contacts.read` and `crm.objects.contacts.write`.
4. Click **Create app**, copy the token (starts with `pat-`), and paste it into Vercel as `HUBSPOT_TOKEN`.

### 2b. Create the custom contact properties
In **Settings → Properties → Contact properties → Create property**, create these six (group them under a new "FDD Scoring" group if you like):

| Property label | Internal name | Field type |
|---|---|---|
| FDD Score | `fdd_score` | Number |
| FDD Grade | `fdd_grade` | Single-line text |
| FDD Brand Name | `fdd_brand_name` | Single-line text |
| FDD Flags | `fdd_flags` | Multi-line text |
| FDD Report Summary | `fdd_report_summary` | Multi-line text |
| FDD Scored At | `fdd_scored_at` | Date picker |

⚠️ The **internal names must match exactly** (lowercase, underscores) — HubSpot sets the internal name when you first type the label, so double-check it before saving.

Every person who scores an FDD now lands in your CRM with their score, grade, flags, and the full line-by-line report summary on their contact record.

---

## Part 3 — Publish the page in HubSpot (~10 min)

1. In HubSpot: **Content → Design Manager** (on some accounts: Marketing → Files and Templates → Design Tools).
2. **File → New file → HTML + HubL** → template type **Page** → name it `fdd-scoring-engine`.
3. Delete everything in the new file and paste the full contents of `frontend/hubspot-page.html`.
4. **One required edit**: near the bottom of the file, find this line and replace it with your real Vercel URL from Part 1:
   ```
   var SCORING_API_URL = "https://YOUR-PROJECT.vercel.app/api/score";
   ```
5. Click **Publish changes** (top right).
6. Now create the page: **Content → Website Pages → Create → Website page**, and when asked for a template, switch the template selector to your coded templates and pick `fdd-scoring-engine`.
7. Give it a URL like `franchiseempire.com/franchise-score`, then **Publish**.

---

## Part 4 — The score email via HubSpot workflow (~10 min, needs Marketing Hub Pro)

The engine stamps the score onto the contact; a workflow sends the email. This keeps the email fully editable by your team without touching code.

1. **Automations → Workflows → Create workflow → From scratch → Contact-based**.
2. Enrollment trigger: **FDD Score is known**. Turn ON re-enrollment ("FDD Scored At is updated") so repeat users get a fresh email.
3. Action: **Send email** → create a new automated email.
4. Design the email using personalization tokens: `FDD Score`, `FDD Grade`, `FDD Brand Name`, `FDD Flags`. Suggested skeleton:

   > **Subject:** Your Franchise Score is in: {{ FDD Score }}/100
   >
   > Hi {{ First name }},
   >
   > Your score for **{{ FDD Brand Name }}** is **{{ FDD Score }}/100 — Grade {{ FDD Grade }}**.
   >
   > Our engine flagged: {{ FDD Flags }}
   >
   > Want the full line-by-line breakdown reviewed with a Franchise Empire advisor? [Book your free score review] → franchiseempire.com/appointment-application

5. Turn the workflow on.

---

## Testing checklist

1. Open your published page, fill in your own name/email, upload a real FDD PDF.
2. You should see the analyzing spinner, then a score within ~1–2 minutes.
3. Check HubSpot: the contact exists with FDD Score, Grade, Flags, and Report Summary filled in.
4. Check your inbox for the workflow email.
5. Try a garbage PDF (e.g., a scanned image) — you should get a friendly error, not a score.

## Troubleshooting

- **"Something went wrong analyzing this FDD"** → In Vercel, open **Deployments → your deployment → Functions logs**. Most common causes: missing/wrong `ANTHROPIC_API_KEY`, or the request timed out on a giant FDD (the function allows 60s).
- **Score works but no contact in HubSpot** → check `HUBSPOT_TOKEN` scopes and that the six property internal names match exactly.
- **Page loads but button does nothing** → the `SCORING_API_URL` line wasn't updated, or `ALLOWED_ORIGIN` doesn't match your site's exact domain (must include `https://www.`).
- **Scanned FDDs** → the engine reads digital text; image-only scans are rejected with a friendly message. These are rare — nearly all FDDs are issued digitally.

## Notes

- The full criterion-by-criterion breakdown is intentionally **never sent to the visitor's browser** — only the score, grade, and top-line findings. The complete report lives on the HubSpot contact record for your advisors, which protects the gated "full breakdown" offer.
- The public tool scores framework Sections 2 and 3 only (Section 1 needs your CRM data; Section 5 was excluded per your decision). Grade labels were rewritten for a public audience ("Exceptional" instead of "promote actively", etc.).
- To change the model, set `ANTHROPIC_MODEL` in Vercel (defaults to `claude-sonnet-5`).
