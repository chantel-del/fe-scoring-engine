const assert = require("assert");
const { scoreBrand } = require("../lib/scoring");

let passed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log("  ✓ " + name); }
  catch (e) { console.error("  ✗ " + name + "\n    " + e.message); process.exitCode = 1; }
}

/* Case 1 — strong service brand, all data available */
const strongService = {
  brand_type: "service",
  royalty_rate_pct: 5,               // 2D: 3/3
  investment_low: 100000,
  investment_high: 200000,           // midpoint 150k
  item19_exists: true,
  item19_pct_reporting: 90,          // 2B: 6/6
  item19_median_revenue: 650000,     // 2A: 650k/150k = 4.33:1 → 16/16
  yoy_revenue_change_pct: 8,         // 2C: 4/4
  item20_years: [
    { year: 2023, start: 90, end: 100, opened: 12, closed: 2, transferred: 1 },
    { year: 2024, start: 100, end: 110, opened: 13, closed: 3, transferred: 2 },
    { year: 2025, start: 110, end: 120, opened: 14, closed: 4, transferred: 2 } // retention (110-4)/110=96.4% → 8/8; transfers 2/115=1.7% → 4/4
  ],
  franchised_units_current: 120,
  year_franchising_began: 2008,      // 18 yrs, 120 units → Bluechip 5/5
  company_owned_units: 4             // 3/3
};

test("strong service brand scores 100/A", () => {
  const r = scoreBrand(strongService);
  assert.strictEqual(r.earned, 49);
  assert.strictEqual(r.available, 49);
  assert.strictEqual(r.score, 100);
  assert.strictEqual(r.grade, "A");
  assert.strictEqual(r.flags.length, 0);
});

/* Case 2 — weak B&M brand with flags */
const weakBM = {
  brand_type: "brick_and_mortar",
  royalty_rate_pct: 9.5,             // 2D: 0/3
  investment_low: 400000,
  investment_high: 600000,           // midpoint 500k
  item19_exists: false,              // 2B: 0/6 + flag
  item19_median_revenue: null,
  item19_avg_revenue: 600000,        // 2A: 600k/500k = 1.2:1 → 0 + flag
  yoy_revenue_change_pct: -20,       // 2C: 0/4 + flag
  item20_years: [
    { year: 2023, start: 50, end: 45, opened: 2, closed: 7, transferred: 4 },
    { year: 2024, start: 45, end: 40, opened: 1, closed: 6, transferred: 5 },
    { year: 2025, start: 40, end: 34, opened: 0, closed: 13, transferred: 5 } // retention (40-13)/40=67.5% → 0 + flag; transfers 5/37=13.5% → 0 + flag
  ],
  franchised_units_current: 34,
  year_franchising_began: 2019,      // 7 yrs, 34 units → Established 4/5
  company_owned_units: 0,
  had_company_owned_previously: true // 3D: 1/3
};

test("weak B&M brand scores low with 5 flags", () => {
  const r = scoreBrand(weakBM);
  assert.strictEqual(r.available, 49);
  assert.strictEqual(r.earned, 5); // 3C:4 + 3D:1
  assert.strictEqual(r.score, 10);
  assert.strictEqual(r.grade, "F");
  assert.strictEqual(r.flags.length, 5);
});

/* Case 3 — missing-data exclusion (no Item 19 numbers, no royalty) */
const partial = {
  brand_type: "service",
  royalty_rate_pct: null,            // 2D excluded
  investment_low: null,
  investment_high: null,             // 2A excluded (no investment)
  item19_exists: true,               // 2B: exists, % unknown → 1/6 (scored, not excluded)
  item19_pct_reporting: null,
  item19_median_revenue: null,
  yoy_revenue_change_pct: null,
  is_first_or_second_fdd: null,      // 2C excluded
  item20_years: [
    { year: 2024, start: 20, end: 25, opened: 6, closed: 1, transferred: 0 },
    { year: 2025, start: 25, end: 30, opened: 6, closed: 1, transferred: 1 }
  ],                                 // <3 yrs → 3A neutral 4/8; 3B: 1/27.5=3.6% → 4/4
  franchised_units_current: 30,
  year_franchising_began: 2022,      // 4 yrs, 30 units → Emerging 3/5
  company_owned_units: 1             // 2/3
};

test("missing data is excluded from denominator", () => {
  const r = scoreBrand(partial);
  // available: 2B(6) + 3A(8) + 3B(4) + 3C(5) + 3D(3) = 26
  assert.strictEqual(r.available, 26);
  // earned: 1 + 4 + 4 + 3 + 2 = 14
  assert.strictEqual(r.earned, 14);
  assert.strictEqual(r.score, 54); // 14/26 = 53.8 → 54
  assert.strictEqual(r.grade, "C");
});

/* Case 4 — unproven brand flag */
test("unproven brand gets 3C flag and 0 pts", () => {
  const r = scoreBrand({
    brand_type: "service",
    franchised_units_current: 8,
    year_franchising_began: 2025
  });
  const c3 = r.criteria.find(c => c.id === "3C");
  assert.strictEqual(c3.earned, 0);
  assert.ok(r.flags.some(f => /unproven/i.test(f)));
});

/* Case 5 — nothing evaluable returns null score */
test("empty data returns null score", () => {
  const r = scoreBrand({ brand_type: "service" });
  assert.strictEqual(r.score, null);
  assert.strictEqual(r.grade, null);
});

/* Case 6 — deductions land on expected score */
test("deductions map to expected score and grade", () => {
  const r = scoreBrand({ ...strongService, royalty_rate_pct: 9.5, company_owned_units: 0, had_company_owned_previously: false });
  // earned = 49 - 3 (2D) - 3 (3D) = 43 → 43/49 = 87.8 → 88 A
  assert.strictEqual(r.score, 88);
  assert.strictEqual(r.grade, "A");
});

console.log(`\n${passed} test group(s) passed${process.exitCode ? " (with failures)" : ""}.`);
